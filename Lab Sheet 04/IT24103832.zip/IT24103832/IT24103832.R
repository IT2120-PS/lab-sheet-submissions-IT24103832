##Part 1
##Setting Directory
setwd("C:/Users/it24103832/Desktop/IT24103832")

##Importing the data set
data <- read.table("DATA 4.txt", header = TRUE, sep = " ")

##View the file in a separate window
fix(data)

##Attach the file into R. So, you can call the variables by their names.
attach(data)

##Part 2
##Part (a)
##Obtaining Box Plots
boxplot(x1,main="Boxplot for Team Attendence",outline=TRUE,outpch=8,horizontal=TRUE)
boxplot(x2,main="Boxplot for Team Salary",outline=TRUE,outpch=8,horizontal=TRUE)
boxplot(x3,main="Boxplot for Years",outline=TRUE,outpch=8,horizontal=TRUE)

##Obtaining Histogram
hist(x1,ylab="Frequency",xlab="Team Attendence",main="Histogram for Team Attendence")
hist(x2,ylab="Frequency",xlab="Team Salary",main="Histogram for Team Salary")
hist(x3,ylab="Frequency",xlab="Years",main="Histogram for Years")

##Stem & Leaf Plot
stem(X1)
stem(X2)
stem(X3)

##Part(b)
##Mean
mean(X1)
mean(X2)
mean(X3)

##Median
median(X1)
median(X2)
median(X3)

##Standard Deviation
sd(X1)
sd(X2)
sd(X3)

##Part (c)
##Getting five number summary along with mean value
summary(X1)
summary(X2)
summary(X3)

##Getting five number summary for x1 variable
quantile(X1)

##Calling first Quantile of X1 using index value
quantile(X1)[2]

##Calling third Quantile of X1 using index value
quantile(X1)[4]

##Part (d)
##Obtaining Inter Quantile Range (IQR) of each variable
IQR(X1)
IQR(X2)
IQR(X3)

##Part 3
##Function to get the mode of a data set
get.mode<-function(y){
  counts<-table(X3)
  names(counts[counts == max(counts)])
}

##Obtaining the mode of a variable using the function defined above
get.mode(X3)

###Explanation on how each command inside the function works 
##Following command is to get the frequency table for the variable 
tabel(X3)

##Following command will give the maximum frequency in the frequency table
max(counts)

##Following command will check whether frequencies in the frequency table equals 
##to the mximum frequency obtained 
counts == max(counts)

##This extracts both value and the frequency which gives "TRUE" in earlier logical function
counts[counts == max(counts)]

##Part 4
##Function to check the existence of outliers of a data set
get.outliers<-function(z){
  q1 <- quantile(z)[2]
  q3 <- quentile (z)[4]
  lqr <- q3 - q1
  ub <- q3 + 1.5 * iqr
  lb <- q1 - 1.5 * iqr
  
  print(paste("Upper Bound = ", ub))
  print(paste("Lower Bound = ", lb))
  print(paste("Outliers:", paste(sort(z[z<lb | z>ub]), collapse = ",")))
}

##Checking the outliers of a variable using the function defined above
get.outliers(X1)
get.outliers(X2)
get.outliers(X3)

#Exercise
##Part 1
#Import the data set
branch_data <- read.table("Exercise.txt", header = TRUE, sep = ",")
#Attach the data frame to be able to call variables by name
attach(branch_data)

##Part 3
#Obtaining Box Plots
boxplot(branch_data$Sales_X1, main = "Boxplot for Sales", horizontal = TRUE)

##Part 4
#Getting five number summary
summary(Advertising_X2)
#Obtaining Inter Quantile Range (IQR) of advertising variable
IQR(Advertising_X2)

##Part 5
#Function to check the existence of Outliers of a data set
get.outliers <- function(z) {
  # Calculate the first quartile (Q1) and third quartile (Q3)
  q1 <- quantile(z, na.rm = TRUE)[2]
  q3 <- quantile(z, na.rm = TRUE)[4]
  # Calculate the Interquartile Range (IQR)
  iqr <- q3 - q1
  # Calculate the lower and upper bounds for outliers
  lb <- q1 - 1.5 * iqr
  ub <- q3 + 1.5 * iqr
  # Find the values that are below the lower bound or above the upper bound
  outliers <- z[z < lb | z > ub]
  # Print the result
  if (length(outliers) > 0) {
    print(paste("Outliers:", paste(sort(outliers), collapse = ", ")))
  } else {
    print("No outliers found.")
  }
}

# Check for outliers in the Years variable
get.outliers(branch_data$Years_X3)

